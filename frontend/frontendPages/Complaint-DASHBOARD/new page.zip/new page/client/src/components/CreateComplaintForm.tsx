import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, queryClient } from '@tanstack/react-query';
import { z } from 'zod';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Plus, Upload, X } from 'lucide-react';

// Form validation schema
const createComplaintSchema = z.object({
  type: z.string().min(1, 'Type is required'),
  description: z.string().min(10, 'Description must be at least 10 characters'),
  location: z.string().min(3, 'Location must be at least 3 characters'),
  priority: z.enum(['HIGH', 'MED', 'LOW']),
  department: z.string().min(1, 'Department is required'),
});

type CreateComplaintData = z.infer<typeof createComplaintSchema>;

const COMPLAINT_TYPES = [
  'Pothole',
  'Streetlight', 
  'Garbage',
  'Drainage',
  'Air Pollution',
  'Water Supply',
  'Road Repair',
  'Park Maintenance',
  'Noise Pollution',
  'Traffic Signal',
  'Sewage',
  'Building Safety'
];

const DEPARTMENTS = [
  'Road Dept.',
  'Electrical',
  'Sanitation', 
  'Public Works',
  'Environment'
];

const PRIORITIES = [
  { value: 'HIGH', label: 'High Priority', color: 'text-red-600' },
  { value: 'MED', label: 'Medium Priority', color: 'text-orange-600' },
  { value: 'LOW', label: 'Low Priority', color: 'text-green-600' }
];

// Animation variants
const modalVariants = {
  hidden: { opacity: 0, scale: 0.8 },
  visible: { 
    opacity: 1, 
    scale: 1,
    transition: { duration: 0.3, ease: "easeOut" }
  },
  exit: { 
    opacity: 0, 
    scale: 0.8,
    transition: { duration: 0.2 }
  }
};

const formVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.4,
      staggerChildren: 0.1,
      delayChildren: 0.1
    }
  }
};

const fieldVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: { 
    opacity: 1, 
    x: 0,
    transition: { duration: 0.3 }
  }
};

interface CreateComplaintFormProps {
  trigger?: React.ReactNode;
}

export function CreateComplaintForm({ trigger }: CreateComplaintFormProps) {
  const [open, setOpen] = useState(false);
  const [attachments, setAttachments] = useState<File[]>([]);
  const { toast } = useToast();

  const form = useForm<CreateComplaintData>({
    resolver: zodResolver(createComplaintSchema),
    defaultValues: {
      type: '',
      description: '',
      location: '',
      priority: 'MED',
      department: ''
    }
  });

  const createComplaintMutation = useMutation({
    mutationFn: async (data: CreateComplaintData) => {
      const response = await apiRequest('POST', '/api/complaints', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success!",
        description: "Complaint has been created successfully.",
        variant: "default",
      });
      
      // Invalidate and refetch complaints
      queryClient.invalidateQueries({ queryKey: ['/api/complaints'] });
      
      // Reset form and close modal
      form.reset();
      setAttachments([]);
      setOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create complaint. Please try again.",
        variant: "destructive",
      });
    }
  });

  const onSubmit = (data: CreateComplaintData) => {
    createComplaintMutation.mutate(data);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files) {
      const newFiles = Array.from(files);
      setAttachments(prev => [...prev, ...newFiles]);
    }
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const defaultTrigger = (
    <Button 
      className="bg-blue-600 hover:bg-blue-700 text-white"
      data-testid="button-new-complaint"
    >
      <Plus className="w-4 h-4 mr-2" />
      New Complaint
    </Button>
  );

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || defaultTrigger}
      </DialogTrigger>
      <DialogContent 
        className="max-w-2xl max-h-[90vh] overflow-y-auto"
        data-testid="dialog-create-complaint"
      >
        <AnimatePresence>
          {open && (
            <motion.div
              variants={modalVariants}
              initial="hidden"
              animate="visible"
              exit="exit"
            >
              <DialogHeader>
                <DialogTitle className="text-2xl font-bold text-blue-600" data-testid="dialog-title">
                  Create New Complaint
                </DialogTitle>
                <DialogDescription data-testid="dialog-description">
                  Fill out the form below to submit a new complaint to the relevant department.
                </DialogDescription>
              </DialogHeader>

              <motion.div
                variants={formVariants}
                initial="hidden"
                animate="visible"
              >
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 mt-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Type Field */}
                      <motion.div variants={fieldVariants}>
                        <FormField
                          control={form.control}
                          name="type"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="font-medium">Complaint Type</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger data-testid="select-type">
                                    <SelectValue placeholder="Select complaint type" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {COMPLAINT_TYPES.map((type) => (
                                    <SelectItem 
                                      key={type} 
                                      value={type}
                                      data-testid={`option-type-${type.toLowerCase().replace(' ', '-')}`}
                                    >
                                      {type}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </motion.div>

                      {/* Priority Field */}
                      <motion.div variants={fieldVariants}>
                        <FormField
                          control={form.control}
                          name="priority"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="font-medium">Priority Level</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger data-testid="select-priority">
                                    <SelectValue placeholder="Select priority" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {PRIORITIES.map((priority) => (
                                    <SelectItem 
                                      key={priority.value} 
                                      value={priority.value}
                                      data-testid={`option-priority-${priority.value.toLowerCase()}`}
                                    >
                                      <span className={priority.color}>{priority.label}</span>
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </motion.div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Location Field */}
                      <motion.div variants={fieldVariants}>
                        <FormField
                          control={form.control}
                          name="location"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="font-medium">Location</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Enter location (e.g., MG Road, Ranchi)" 
                                  {...field} 
                                  data-testid="input-location"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </motion.div>

                      {/* Department Field */}
                      <motion.div variants={fieldVariants}>
                        <FormField
                          control={form.control}
                          name="department"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="font-medium">Department</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger data-testid="select-department">
                                    <SelectValue placeholder="Select department" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {DEPARTMENTS.map((dept) => (
                                    <SelectItem 
                                      key={dept} 
                                      value={dept}
                                      data-testid={`option-department-${dept.toLowerCase().replace(' ', '-').replace('.', '')}`}
                                    >
                                      {dept}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </motion.div>
                    </div>

                    {/* Description Field */}
                    <motion.div variants={fieldVariants}>
                      <FormField
                        control={form.control}
                        name="description"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="font-medium">Description</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Provide a detailed description of the complaint..."
                                className="min-h-[120px] resize-none"
                                {...field}
                                data-testid="textarea-description"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </motion.div>

                    {/* File Upload Section */}
                    <motion.div variants={fieldVariants} className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Attachments (Optional)
                        </label>
                        <div className="flex items-center justify-center w-full">
                          <label 
                            htmlFor="file-upload"
                            className="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition-colors"
                            data-testid="file-upload-area"
                          >
                            <div className="flex flex-col items-center justify-center pt-5 pb-6">
                              <Upload className="w-8 h-8 mb-2 text-gray-400" />
                              <p className="mb-2 text-sm text-gray-500">
                                <span className="font-semibold">Click to upload</span> or drag and drop
                              </p>
                              <p className="text-xs text-gray-500">PNG, JPG, PDF up to 10MB</p>
                            </div>
                            <input
                              id="file-upload"
                              type="file"
                              multiple
                              accept="image/*,.pdf"
                              className="hidden"
                              onChange={handleFileChange}
                              data-testid="input-file-upload"
                            />
                          </label>
                        </div>
                      </div>

                      {/* Attachment List */}
                      <AnimatePresence>
                        {attachments.length > 0 && (
                          <motion.div 
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="space-y-2"
                          >
                            <h4 className="text-sm font-medium text-gray-700">Attached Files:</h4>
                            {attachments.map((file, index) => (
                              <motion.div
                                key={index}
                                initial={{ opacity: 0, x: -20 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: 20 }}
                                className="flex items-center justify-between bg-gray-100 px-3 py-2 rounded-md"
                                data-testid={`attachment-${index}`}
                              >
                                <span className="text-sm text-gray-700 truncate">{file.name}</span>
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => removeAttachment(index)}
                                  data-testid={`button-remove-attachment-${index}`}
                                >
                                  <X className="w-4 h-4" />
                                </Button>
                              </motion.div>
                            ))}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>

                    {/* Form Actions */}
                    <motion.div 
                      variants={fieldVariants}
                      className="flex justify-end space-x-4 pt-6 border-t"
                    >
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => setOpen(false)}
                        data-testid="button-cancel"
                      >
                        Cancel
                      </Button>
                      <Button 
                        type="submit" 
                        className="bg-blue-600 hover:bg-blue-700 text-white"
                        disabled={createComplaintMutation.isPending}
                        data-testid="button-submit-complaint"
                      >
                        {createComplaintMutation.isPending ? (
                          <motion.div
                            animate={{ rotate: 360 }}
                            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                            className="w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"
                          />
                        ) : null}
                        {createComplaintMutation.isPending ? 'Creating...' : 'Create Complaint'}
                      </Button>
                    </motion.div>
                  </form>
                </Form>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}