import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useQuery } from '@tanstack/react-query';
import { type Complaint } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';

// Framer Motion Variants
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1, 
    y: 0,
    transition: { duration: 0.5, ease: "easeOut" }
  }
};

const cardVariants = {
  hidden: { opacity: 0, scale: 0.8 },
  visible: { 
    opacity: 1, 
    scale: 1,
    transition: { duration: 0.4, ease: "easeOut" }
  },
  hover: { 
    scale: 1.02,
    transition: { duration: 0.2 }
  }
};

const tableRowVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: { 
    opacity: 1, 
    x: 0,
    transition: { duration: 0.3 }
  },
  exit: { 
    opacity: 0, 
    x: 20,
    transition: { duration: 0.2 }
  }
};

export default function Dashboard() {
  // State Variables
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [statusFilter, setStatusFilter] = useState('All');
  const [priorityFilter, setPriorityFilter] = useState<string[]>([]);
  const [categoryFilter, setCategoryFilter] = useState('All Categories');
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  // Fetch complaints
  const { data: complaintsData, isLoading } = useQuery<Complaint[]>({
    queryKey: ['/api/complaints'],
    staleTime: 30000,
  });

  useEffect(() => {
    if (complaintsData && Array.isArray(complaintsData)) {
      setComplaints(complaintsData);
    }
  }, [complaintsData]);

  // Filtering Logic
  const filteredComplaints = useMemo(() => {
    let filtered = complaints.filter(complaint => {
      // Status filter
      if (statusFilter !== 'All' && complaint.status !== statusFilter) return false;
      
      // Priority filter
      if (priorityFilter.length > 0 && !priorityFilter.includes(complaint.priority)) return false;
      
      // Category filter
      if (categoryFilter !== 'All Categories' && complaint.department !== categoryFilter) return false;
      
      // Search filter
      if (searchTerm) {
        const searchLower = searchTerm.toLowerCase();
        const searchableText = [
          complaint.id,
          complaint.type,
          complaint.description,
          complaint.location,
          complaint.department,
          complaint.assignedTo
        ].join(' ').toLowerCase();
        
        if (!searchableText.includes(searchLower)) return false;
      }
      
      return true;
    });
    
    return filtered;
  }, [complaints, statusFilter, priorityFilter, categoryFilter, searchTerm]);

  // Pagination calculation
  const totalPages = Math.ceil(filteredComplaints.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedComplaints = filteredComplaints.slice(startIndex, startIndex + itemsPerPage);

  // Metrics calculation
  const metrics = useMemo(() => {
    const total = filteredComplaints.length;
    const pending = filteredComplaints.filter(c => c.status === 'PENDING').length;
    const inProgress = filteredComplaints.filter(c => c.status === 'IN PROGRESS').length;
    const resolved = filteredComplaints.filter(c => c.status === 'RESOLVED').length;
    const resolutionRate = total > 0 ? ((resolved / total) * 100).toFixed(1) : 0;
    
    return { total, pending, inProgress, resolved, resolutionRate };
  }, [filteredComplaints]);

  // Action Handler Function
  const handleAction = async (complaintId: string, action: string) => {
    try {
      let newStatus = '';
      let message = '';

      switch (action) {
        case 'assign':
          newStatus = 'IN PROGRESS';
          message = `Complaint ${complaintId} assigned successfully`;
          break;
        case 'update':
          newStatus = 'RESOLVED';
          message = `Complaint ${complaintId} status updated`;
          break;
        case 'view':
          const complaint = complaints.find(c => c.id === complaintId);
          alert(`Viewing complaint ${complaintId}: ${complaint?.description}`);
          return;
        default:
          return;
      }

      if (newStatus) {
        const response = await apiRequest('PATCH', `/api/complaints/${complaintId}`, { status: newStatus });
        
        setComplaints(prev => prev.map(complaint => {
          if (complaint.id === complaintId) {
            return { ...complaint, status: newStatus };
          }
          return complaint;
        }));

        alert(message);
      }
    } catch (error) {
      console.error('Error updating complaint:', error);
      alert('Failed to update complaint');
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Loading dashboard...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50" data-testid="dashboard-container">
      {/* Header */}
      <motion.header 
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-6"
        data-testid="header"
      >
        <h1 className="text-3xl font-bold" data-testid="header-title">ECOSATHI</h1>
        <p className="text-blue-100 mt-1" data-testid="header-subtitle">Admin Dashboard - Complaint Management</p>
      </motion.header>

      {/* Metrics Cards */}
      <motion.div 
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 p-6"
        data-testid="metrics-container"
      >
        <motion.div variants={cardVariants} whileHover="hover" className="bg-white rounded-lg shadow-sm p-6" data-testid="metric-total">
          <div className="text-2xl font-bold text-gray-900" data-testid="metric-total-value">{metrics.total}</div>
          <div className="text-sm text-gray-600">Total Complaints</div>
          <div className="text-sm text-green-600 mt-1">+12% this week</div>
        </motion.div>
        
        <motion.div variants={cardVariants} whileHover="hover" className="bg-white rounded-lg shadow-sm p-6" data-testid="metric-pending">
          <div className="text-2xl font-bold text-red-600" data-testid="metric-pending-value">{metrics.pending}</div>
          <div className="text-sm text-gray-600">Pending</div>
          <div className="text-sm text-red-600 mt-1">Needs attention</div>
        </motion.div>
        
        <motion.div variants={cardVariants} whileHover="hover" className="bg-white rounded-lg shadow-sm p-6" data-testid="metric-progress">
          <div className="text-2xl font-bold text-orange-600" data-testid="metric-progress-value">{metrics.inProgress}</div>
          <div className="text-sm text-gray-600">In Progress</div>
          <div className="text-sm text-orange-600 mt-1">Active resolution</div>
        </motion.div>
        
        <motion.div variants={cardVariants} whileHover="hover" className="bg-white rounded-lg shadow-sm p-6" data-testid="metric-resolved">
          <div className="text-2xl font-bold text-green-600" data-testid="metric-resolved-value">{metrics.resolved}</div>
          <div className="text-sm text-gray-600">Resolved</div>
          <div className="text-sm text-green-600 mt-1" data-testid="metric-resolution-rate">{metrics.resolutionRate}% resolution rate</div>
        </motion.div>
      </motion.div>

      {/* Filters Section */}
      <motion.div 
        initial={{ opacity: 0, x: -50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
        className="bg-white p-6 shadow-sm"
        data-testid="filters-container"
      >
        <div className="flex flex-wrap gap-4 items-center">
          {/* Status Filters */}
          <div className="flex gap-2">
            <span className="text-sm font-medium text-gray-700 mr-2">Status:</span>
            {['All', 'PENDING', 'IN PROGRESS', 'RESOLVED'].map(status => (
              <motion.button
                key={status}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setStatusFilter(status)}
                className={`px-3 py-1 rounded-md text-sm font-medium transition-colors ${
                  statusFilter === status 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
                data-testid={`filter-status-${status.toLowerCase().replace(' ', '-')}`}
              >
                {status}
              </motion.button>
            ))}
          </div>

          {/* Priority Filters */}
          <div className="flex gap-2">
            <span className="text-sm font-medium text-gray-700 mr-2">Priority:</span>
            {[
              { key: 'HIGH', label: 'High', color: 'bg-red-600 hover:bg-red-700' },
              { key: 'MED', label: 'Medium', color: 'bg-orange-500 hover:bg-orange-600' },
              { key: 'LOW', label: 'Low', color: 'bg-green-600 hover:bg-green-700' }
            ].map(priority => (
              <motion.button
                key={priority.key}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => {
                  setPriorityFilter(prev => 
                    prev.includes(priority.key)
                      ? prev.filter(p => p !== priority.key)
                      : [...prev, priority.key]
                  );
                }}
                className={`px-3 py-1 rounded-md text-sm font-medium text-white transition-colors ${
                  priorityFilter.includes(priority.key) 
                    ? priority.color 
                    : 'bg-gray-300 hover:bg-gray-400'
                }`}
                data-testid={`filter-priority-${priority.label.toLowerCase()}`}
              >
                {priority.label}
              </motion.button>
            ))}
          </div>

          {/* Category Dropdown */}
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-1 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            data-testid="filter-category"
          >
            <option value="All Categories">All Categories</option>
            <option value="Road Dept.">Road Dept.</option>
            <option value="Electrical">Electrical</option>
            <option value="Sanitation">Sanitation</option>
            <option value="Public Works">Public Works</option>
            <option value="Environment">Environment</option>
          </select>

          {/* Search Input */}
          <div className="flex-1 min-w-64">
            <motion.input
              whileFocus={{ scale: 1.02 }}
              type="text"
              placeholder="Search complaints..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-md text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              data-testid="search-input"
            />
          </div>
        </div>
      </motion.div>

      {/* Table */}
      <motion.div 
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.5 }}
        className="bg-white shadow-sm rounded-lg overflow-hidden m-6"
        data-testid="complaints-table"
      >
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Priority</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Department</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Submitted</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              <AnimatePresence>
                {paginatedComplaints.map((complaint, index) => (
                  <motion.tr
                    key={complaint.id}
                    variants={tableRowVariants}
                    initial="hidden"
                    animate="visible"
                    exit="exit"
                    whileHover={{ backgroundColor: "#F9FAFB" }}
                    className={`${
                      complaint.priority === 'HIGH' ? 'border-l-4 border-red-500' :
                      complaint.priority === 'MED' ? 'border-l-4 border-orange-500' :
                      'border-l-4 border-green-500'
                    }`}
                    data-testid={`complaint-row-${complaint.id}`}
                  >
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900" data-testid={`complaint-id-${complaint.id}`}>{complaint.id}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900" data-testid={`complaint-type-${complaint.id}`}>{complaint.type}</td>
                    <td className="px-6 py-4 text-sm text-gray-900 max-w-xs truncate" data-testid={`complaint-desc-${complaint.id}`}>{complaint.description}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900" data-testid={`complaint-location-${complaint.id}`}>{complaint.location}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        complaint.priority === 'HIGH' ? 'bg-red-100 text-red-800' :
                        complaint.priority === 'MED' ? 'bg-orange-100 text-orange-800' :
                        'bg-green-100 text-green-800'
                      }`} data-testid={`complaint-priority-${complaint.id}`}>
                        {complaint.priority}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        complaint.status === 'PENDING' ? 'bg-red-100 text-red-800' :
                        complaint.status === 'IN PROGRESS' ? 'bg-orange-100 text-orange-800' :
                        'bg-green-100 text-green-800'
                      }`} data-testid={`complaint-status-${complaint.id}`}>
                        {complaint.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900" data-testid={`complaint-dept-${complaint.id}`}>{complaint.department}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500" data-testid={`complaint-submitted-${complaint.id}`}>{complaint.submitted}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm space-x-2">
                      {complaint.status === 'PENDING' && (
                        <motion.button
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          onClick={() => handleAction(complaint.id, 'assign')}
                          className="bg-blue-600 text-white px-3 py-1 rounded-md text-xs hover:bg-blue-700 transition-colors"
                          data-testid={`button-assign-${complaint.id}`}
                        >
                          ASSIGN
                        </motion.button>
                      )}
                      {complaint.status === 'IN PROGRESS' && (
                        <motion.button
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          onClick={() => handleAction(complaint.id, 'update')}
                          className="bg-green-600 text-white px-3 py-1 rounded-md text-xs hover:bg-green-700 transition-colors"
                          data-testid={`button-update-${complaint.id}`}
                        >
                          UPDATE
                        </motion.button>
                      )}
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => handleAction(complaint.id, 'view')}
                        className="bg-gray-600 text-white px-3 py-1 rounded-md text-xs hover:bg-gray-700 transition-colors"
                        data-testid={`button-view-${complaint.id}`}
                      >
                        VIEW
                      </motion.button>
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Pagination */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8 }}
        className="bg-white px-6 py-3 flex items-center justify-between border-t border-gray-200"
        data-testid="pagination-container"
      >
        <div className="text-sm text-gray-700" data-testid="pagination-info">
          Showing {startIndex + 1}-{Math.min(startIndex + itemsPerPage, filteredComplaints.length)} of {filteredComplaints.length} complaints
        </div>
        <div className="flex space-x-2">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
            className={`px-3 py-1 rounded-md text-sm ${
              currentPage === 1 
                ? 'bg-gray-100 text-gray-400 cursor-not-allowed' 
                : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
            }`}
            data-testid="button-previous"
          >
            Previous
          </motion.button>
          
          {Array.from({ length: totalPages }, (_, i) => i + 1).map(page => (
            <motion.button
              key={page}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setCurrentPage(page)}
              className={`px-3 py-1 rounded-md text-sm ${
                currentPage === page 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
              }`}
              data-testid={`button-page-${page}`}
            >
              {page}
            </motion.button>
          ))}
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
            className={`px-3 py-1 rounded-md text-sm ${
              currentPage === totalPages 
                ? 'bg-gray-100 text-gray-400 cursor-not-allowed' 
                : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
            }`}
            data-testid="button-next"
          >
            Next
          </motion.button>
        </div>
      </motion.div>

      {/* Priority Legend */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="p-6 bg-gray-50"
        data-testid="priority-legend"
      >
        <h3 className="text-sm font-medium text-gray-700 mb-3">Priority Legend:</h3>
        <div className="flex flex-wrap gap-4">
          <div className="flex items-center">
            <div className="w-3 h-3 bg-red-500 rounded mr-2"></div>
            <span className="text-sm text-gray-600">High Priority (urgent issues requiring immediate attention)</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-orange-500 rounded mr-2"></div>
            <span className="text-sm text-gray-600">Medium Priority (important but not urgent)</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-green-500 rounded mr-2"></div>
            <span className="text-sm text-gray-600">Low Priority (non-urgent maintenance)</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
