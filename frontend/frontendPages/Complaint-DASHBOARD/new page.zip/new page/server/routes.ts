import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertComplaintSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize complaints data on startup
  await storage.initializeComplaints();

  // Get all complaints
  app.get("/api/complaints", async (req, res) => {
    try {
      const complaints = await storage.getAllComplaints();
      res.json(complaints);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch complaints" });
    }
  });

  // Get single complaint
  app.get("/api/complaints/:id", async (req, res) => {
    try {
      const complaint = await storage.getComplaint(req.params.id);
      if (!complaint) {
        return res.status(404).json({ message: "Complaint not found" });
      }
      res.json(complaint);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch complaint" });
    }
  });

  // Create new complaint
  app.post("/api/complaints", async (req, res) => {
    try {
      // Generate unique complaint ID
      const existingComplaints = await storage.getAllComplaints();
      const highestId = existingComplaints
        .map(c => parseInt(c.id.replace('#', '')))
        .filter(id => !isNaN(id))
        .sort((a, b) => b - a)[0] || 2847;
      
      const newId = `#${highestId + 1}`;
      
      // Auto-populate certain fields
      const complaintData = {
        ...req.body,
        id: newId,
        status: "PENDING" as const,
        submitted: "Just now",
        assignedTo: "Unassigned",
        dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0] // 3 days from now
      };

      // Validate the complaint data
      const validatedComplaint = insertComplaintSchema.parse(complaintData);
      
      const newComplaint = await storage.createComplaint(validatedComplaint);
      res.status(201).json(newComplaint);
    } catch (error) {
      console.error('Error creating complaint:', error);
      res.status(400).json({ message: error instanceof Error ? error.message : "Failed to create complaint" });
    }
  });

  // Update complaint
  app.patch("/api/complaints/:id", async (req, res) => {
    try {
      const updated = await storage.updateComplaint(req.params.id, req.body);
      if (!updated) {
        return res.status(404).json({ message: "Complaint not found" });
      }
      res.json(updated);
    } catch (error) {
      res.status(500).json({ message: "Failed to update complaint" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
