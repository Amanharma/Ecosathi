import { type User, type InsertUser, type Complaint, type InsertComplaint, users, complaints } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllComplaints(): Promise<Complaint[]>;
  getComplaint(id: string): Promise<Complaint | undefined>;
  createComplaint(complaint: InsertComplaint): Promise<Complaint>;
  updateComplaint(id: string, updates: Partial<Complaint>): Promise<Complaint | undefined>;
  deleteComplaint(id: string): Promise<boolean>;
  initializeComplaints(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getAllComplaints(): Promise<Complaint[]> {
    const result = await db.select().from(complaints);
    return result;
  }

  async getComplaint(id: string): Promise<Complaint | undefined> {
    const [complaint] = await db.select().from(complaints).where(eq(complaints.id, id));
    return complaint || undefined;
  }

  async createComplaint(complaint: InsertComplaint): Promise<Complaint> {
    const [newComplaint] = await db
      .insert(complaints)
      .values(complaint)
      .returning();
    return newComplaint;
  }

  async updateComplaint(id: string, updates: Partial<Complaint>): Promise<Complaint | undefined> {
    const [updated] = await db
      .update(complaints)
      .set(updates)
      .where(eq(complaints.id, id))
      .returning();
    return updated || undefined;
  }

  async deleteComplaint(id: string): Promise<boolean> {
    const result = await db.delete(complaints).where(eq(complaints.id, id));
    return (result.rowCount || 0) > 0;
  }

  async initializeComplaints(): Promise<void> {
    // Check if complaints already exist
    const existing = await this.getAllComplaints();
    if (existing.length > 0) {
      return; // Data already exists, don't re-initialize
    }

    const INITIAL_COMPLAINTS: InsertComplaint[] = [
      {
        id: "#2847",
        type: "Pothole",
        description: "Large pothole causing traffic issues",
        location: "MG Road, Ranchi",
        priority: "HIGH",
        status: "PENDING",
        department: "Road Dept.",
        submitted: "2 hours ago",
        assignedTo: "John Smith",
        dueDate: "2024-09-18"
      },
      {
        id: "#2846",
        type: "Streetlight",
        description: "Streetlight not working near school",
        location: "Circular Road",
        priority: "MED",
        status: "IN PROGRESS",
        department: "Electrical",
        submitted: "5 hours ago",
        assignedTo: "Sarah Wilson",
        dueDate: "2024-09-17"
      },
      {
        id: "#2845",
        type: "Garbage",
        description: "Overflowing dustbin near market",
        location: "Main Bazaar",
        priority: "LOW",
        status: "RESOLVED",
        department: "Sanitation",
        submitted: "1 day ago",
        assignedTo: "Mike Davis",
        dueDate: "2024-09-16"
      },
      {
        id: "#2844",
        type: "Drainage",
        description: "Water logging during monsoon",
        location: "Station Road",
        priority: "HIGH",
        status: "IN PROGRESS",
        department: "Public Works",
        submitted: "3 hours ago",
        assignedTo: "Lisa Chen",
        dueDate: "2024-09-18"
      },
      {
        id: "#2843",
        type: "Air Pollution",
        description: "Industrial smoke emission",
        location: "Industrial Area",
        priority: "MED",
        status: "PENDING",
        department: "Environment",
        submitted: "6 hours ago",
        assignedTo: "Robert Brown",
        dueDate: "2024-09-20"
      },
      {
        id: "#2842",
        type: "Water Supply",
        description: "No water supply for 3 days",
        location: "Residential Colony A",
        priority: "HIGH",
        status: "RESOLVED",
        department: "Public Works",
        submitted: "2 days ago",
        assignedTo: "Anna Kumar",
        dueDate: "2024-09-15"
      },
      {
        id: "#2841",
        type: "Road Repair",
        description: "Damaged road after heavy rain",
        location: "Gandhi Street",
        priority: "MED",
        status: "PENDING",
        department: "Road Dept.",
        submitted: "4 hours ago",
        assignedTo: "David Lee",
        dueDate: "2024-09-19"
      },
      {
        id: "#2840",
        type: "Park Maintenance",
        description: "Broken swings in children park",
        location: "Central Park",
        priority: "LOW",
        status: "IN PROGRESS",
        department: "Public Works",
        submitted: "1 day ago",
        assignedTo: "Emily White",
        dueDate: "2024-09-22"
      },
      {
        id: "#2839",
        type: "Noise Pollution",
        description: "Loud construction work at night",
        location: "Residential Area B",
        priority: "MED",
        status: "RESOLVED",
        department: "Environment",
        submitted: "3 days ago",
        assignedTo: "James Wilson",
        dueDate: "2024-09-14"
      },
      {
        id: "#2838",
        type: "Traffic Signal",
        description: "Malfunctioning traffic light",
        location: "Main Intersection",
        priority: "HIGH",
        status: "PENDING",
        department: "Road Dept.",
        submitted: "1 hour ago",
        assignedTo: "Sophie Taylor",
        dueDate: "2024-09-16"
      },
      {
        id: "#2837",
        type: "Sewage",
        description: "Blocked sewage line causing overflow",
        location: "Market Street",
        priority: "HIGH",
        status: "IN PROGRESS",
        department: "Sanitation",
        submitted: "8 hours ago",
        assignedTo: "Tom Anderson",
        dueDate: "2024-09-17"
      },
      {
        id: "#2836",
        type: "Building Safety",
        description: "Cracks in government building wall",
        location: "City Hall",
        priority: "MED",
        status: "PENDING",
        department: "Public Works",
        submitted: "2 days ago",
        assignedTo: "Maria Garcia",
        dueDate: "2024-09-25"
      }
    ];

    // Insert all initial complaints
    await db.insert(complaints).values(INITIAL_COMPLAINTS);
  }
}

export const storage = new DatabaseStorage();
