CREATE TABLE "complaints" (
	"id" varchar PRIMARY KEY NOT NULL,
	"type" text NOT NULL,
	"description" text NOT NULL,
	"location" text NOT NULL,
	"priority" varchar(10) NOT NULL,
	"status" varchar(20) NOT NULL,
	"department" text NOT NULL,
	"submitted" text NOT NULL,
	"assignedTo" text NOT NULL,
	"dueDate" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"username" text NOT NULL,
	"password" text NOT NULL,
	CONSTRAINT "users_username_unique" UNIQUE("username")
);
